
import java.awt.Color;
public class NewApplet2 extends java.applet.Applet {
    public void init() {
        try {
            java.awt.EventQueue.invokeAndWait(new Runnable() {

                public void run() {
                    initComponents();
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel1 = new java.awt.Panel();
        label2 = new java.awt.Label();
        textField1 = new java.awt.TextField();
        button1 = new java.awt.Button();

        setLayout(new java.awt.BorderLayout());

        label2.setFont(new java.awt.Font("Times New Roman", 2, 12)); // NOI18N
        label2.setPreferredSize(new java.awt.Dimension(250, 20));
        label2.setText("label2");
        panel1.add(label2);

        textField1.setText("textField1");
        panel1.add(textField1);

        button1.setLabel("BAS");
        button1.setPreferredSize(new java.awt.Dimension(100, 24));
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        panel1.add(button1);

        add(panel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
  label2.setBackground(Color.BLUE);
  label2.setText("ButonaBasıldı");
  String kelime=textField1.getText();
  label2.setText(kelime);
  
  
    }//GEN-LAST:event_button1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button1;
    private java.awt.Label label2;
    private java.awt.Panel panel1;
    private java.awt.TextField textField1;
    // End of variables declaration//GEN-END:variables
}
