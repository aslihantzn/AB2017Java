
public class İkinci extends java.applet.Applet {
    public void init() {
        try {
            java.awt.EventQueue.invokeAndWait(new Runnable() {

                public void run() {
                    initComponents();
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel1 = new java.awt.Panel();
        textField1 = new java.awt.TextField();
        button1 = new java.awt.Button();
        label1 = new java.awt.Label();
        label2 = new java.awt.Label();

        setLayout(new java.awt.BorderLayout());

        textField1.setPreferredSize(new java.awt.Dimension(150, 20));
        textField1.setText("Kelime Gir");
        panel1.add(textField1);

        button1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        button1.setLabel("Göster");
        button1.setPreferredSize(new java.awt.Dimension(100, 100));
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        panel1.add(button1);

        label1.setBackground(new java.awt.Color(255, 255, 51));
        label1.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        label1.setPreferredSize(new java.awt.Dimension(150, 26));
        label1.setText("Sesliler");
        panel1.add(label1);

        label2.setBackground(new java.awt.Color(255, 0, 0));
        label2.setFont(new java.awt.Font("Microsoft Sans Serif", 2, 18)); // NOI18N
        label2.setPreferredSize(new java.awt.Dimension(150, 25));
        label2.setText("Sessizler");
        panel1.add(label2);

        add(panel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        char sesli[]={'a','e','ı','i','o','ö','u','ü'};
        String kelime,sesliler="",sessizler="";
        boolean s;
        int i,j;
        kelime=textField1.getText();
        for(i=0;i<kelime.length();i++)
        {   
                s=false;
                    for (j=0;j<sesli.length;j++) 
                        if ((kelime.charAt(i)==sesli[j])) 
                        {s=true; break;}

                if (s) 
                    sesliler=sesliler+kelime.charAt(i); 
                else sessizler=sessizler+kelime.charAt(i);  
               
    }//GEN-LAST:event_button1ActionPerformed
        
        label1.setText(sesliler);
        label2.setText(sessizler);

    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button1;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private java.awt.Panel panel1;
    private java.awt.TextField textField1;
    // End of variables declaration//GEN-END:variables
}
