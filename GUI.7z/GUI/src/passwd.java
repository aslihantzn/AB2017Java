
public class passwd extends java.applet.Applet {
    String passwd="GALATASARAY";
    int hak=0;

    public void init() {
        
        
        try {
            java.awt.EventQueue.invokeAndWait(new Runnable() {

                public void run() {
                    initComponents();
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel1 = new java.awt.Panel();
        label1 = new java.awt.Label();
        textField1 = new java.awt.TextField();
        button1 = new java.awt.Button();

        setLayout(new java.awt.BorderLayout());

        label1.setText("label1");
        panel1.add(label1);

        textField1.setText("textField1");
        textField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField1KeyPressed(evt);
            }
        });
        panel1.add(textField1);

        button1.setLabel("button1");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        panel1.add(button1);

        add(panel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents
 
    private void textField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField1KeyPressed
           textField1.setEchoChar('*');        // TODO add your handling code here:
    }//GEN-LAST:event_textField1KeyPressed

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        if (hak++<3)
        { if (textField1.getText().equals(passwd)) label1.setText("Şifre Doğru");
        else label1.setText("Şifre Yanlış");
        }
        if (hak==3) textField1.setEditable(false);//veya programı kapa System.exit(0);
        // TODO add your handling code here:
    }//GEN-LAST:event_button1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button1;
    private java.awt.Label label1;
    private java.awt.Panel panel1;
    private java.awt.TextField textField1;
    // End of variables declaration//GEN-END:variables
}
