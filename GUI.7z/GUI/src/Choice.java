
public class Choice extends java.applet.Applet {

    public void init() {
        try {
            java.awt.EventQueue.invokeAndWait(new Runnable() {

                public void run() {
                    initComponents();
                   for (int i=1;i<=20;i++) 
                    {
                    choice1.addItem(""+i);
                    choice2.addItem(""+i);
                    }

                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel1 = new java.awt.Panel();
        choice1 = new java.awt.Choice();
        label1 = new java.awt.Label();
        choice2 = new java.awt.Choice();
        button1 = new java.awt.Button();

        setLayout(new java.awt.BorderLayout());

        choice1.setPreferredSize(new java.awt.Dimension(50, 20));
        choice1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                choice1İtemStateChanged(evt);
            }
        });
        panel1.add(choice1);

        label1.setText("label1");
        panel1.add(label1);

        choice2.setPreferredSize(new java.awt.Dimension(50, 20));
        choice2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                choice2İtemStateChanged(evt);
            }
        });
        panel1.add(choice2);

        button1.setLabel("button1");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        panel1.add(button1);

        add(panel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void choice2İtemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_choice2İtemStateChanged
        int i,sınır1,sınır2,toplam=0;
        sınır1=Integer.parseInt(label1.getText());//Integer.parseInt(choice1.getSelectedItem());
        sınır2=Integer.parseInt(choice2.getSelectedItem());
        if (sınır2>sınır1) 
        {    for (i=sınır1;i<=sınır2;i++)
            {
                toplam+=i;
            }
            label1.setText(""+toplam/((sınır2-sınır1)+1));
            
        }else label1.setText("ilk sınır 2. den küçük olmalıdır");
        
    }//GEN-LAST:event_choice2İtemStateChanged

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        
    }//GEN-LAST:event_button1ActionPerformed

    private void choice1İtemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_choice1İtemStateChanged
         label1.setText(choice1.getSelectedItem());        // TODO add your handling code here:
    }//GEN-LAST:event_choice1İtemStateChanged

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button1;
    private java.awt.Choice choice1;
    private java.awt.Choice choice2;
    private java.awt.Label label1;
    private java.awt.Panel panel1;
    // End of variables declaration//GEN-END:variables
}
