import java.security.KeyStore.Entry;
import java.util.HashMap;
import java.util.Set;


public class Arama{

	static HashMap<Integer,String> ogrenci = new HashMap<Integer, String>();
	Set<Integer>ogrler=ogrenci.keySet();
	public int ara(int no){
		String ad;
		ad= ogrenci.get(no);
		if(ad!=null)
			System.out.println("Aranan öğrencinin adı: "+ad);
		else
			System.out.println("Girilen numaraya uygun öğrenci bulunamamıştır");
		return 0;
	}
	public void ekle(String ad,Integer no){
		ogrenci.put(no, ad);
		System.out.print("Başarıyla eklendi.");
	}
}

