import java.util.Scanner;


public class Otomasyon {
	
	public static String ad;
	public String soyad;
	public static int no;
	Arama aranacak=new Arama();// Arama sınıfına erişmek için kullanıyoruz.

	public static void main(String[] args) {
		while(1==1){
			int secim;
			Arama arama=new Arama();// Arama sınıfına erişmek için kullanıyoruz.
			System.out.print("1-Arama\n2-Öğrenci Ekleme\n");
			Scanner giris1=new Scanner(System.in);
			secim=giris1.nextInt();
			switch (secim) {
			case 1:
				System.out.println("Aramak istediğiniz öğrencinin numarasını giriniz:");
				Scanner giris2=new Scanner(System.in);
				no=giris2.nextInt();
				arama.ara(no);
				break;
			case 2:
				String ad;
				int no;
				System.out.println("Eklenecek öğrencinin adını ve numarasını giriniz:");
				Scanner giris3=new Scanner(System.in);
				ad=giris3.nextLine();
				Scanner giris4=new Scanner(System.in);
				no=giris4.nextInt();
				arama.ekle(ad, no);
			default:
				break;
			}
		}
	}

}
